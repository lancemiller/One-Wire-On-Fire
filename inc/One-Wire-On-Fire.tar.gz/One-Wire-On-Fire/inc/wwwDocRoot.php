<?php
print $_SERVER["DOCUMENT_ROOT"];
die();
?>

